#Group: Ubuntu/Base
#file: /opt/jiffy/gary/Public/Configs/Ubuntu/Base/CHROOTFILES/usr
#version: 1
#file_check_hash: 8d0fab19094ae7125bfc09838af84935
#file_ref_hash: 4288e1610d7524d6a7ac18160935eb56
directory '/usr' do
    owner 'root'
    group 'root'
    mode '0755'
end

#Group: Ubuntu/Base
#file: /opt/jiffy/gary/Public/Configs/Ubuntu/Base/CHROOTFILES/etc
#version: 1
#file_check_hash: 32d539ef88f469af099793f9e69fe807
#file_ref_hash: 78bb2a91fa274ac0321aaa106fd5313b
directory '/etc' do
    owner 'root'
    group 'root'
    mode '0755'
end

#Group: Ubuntu/Base
#file: /opt/jiffy/gary/Public/Configs/Ubuntu/Base/CHROOTFILES/root
#version: 1
#file_check_hash: 800d62b68b241e910210642883690cdd
#file_ref_hash: d31196d9064a6d77014192557b8e03c4
directory '/root' do
    owner 'root'
    group 'root'
    mode '0700'
end

#Group: Ubuntu/Base
#file: /opt/jiffy/gary/Public/Configs/Ubuntu/Base/CHROOTFILES/usr/local
#version: 1
#file_check_hash: 84eafbe907b424d4e787372ae91da66d
#file_ref_hash: dcf84cf82ba68bb6b894ac56bf580919
directory '/usr/local' do
    owner 'root'
    group 'root'
    mode '0755'
end

#Group: Ubuntu/Base
#file: /opt/jiffy/gary/Public/Configs/Ubuntu/Base/CHROOTFILES/usr/local/scripts
#version: 1
#file_check_hash: ce8ddc5067681d44d9a159fca65ebcf2
#file_ref_hash: 49ff6058675e94bacf81aee16aeb1b59
directory '/usr/local/scripts' do
    owner 'root'
    group 'root'
    mode '0755'
end

#Group: Ubuntu/Base
#file: /opt/jiffy/gary/Public/Configs/Ubuntu/Base/CHROOTFILES/etc/ssh
#version: 1
#file_check_hash: 2d072354e76d5f6d05fb478bdefa0399
#file_ref_hash: d65339a2ae8ee5b4bfe653dea98c0639
directory '/etc/ssh' do
    owner 'root'
    group 'root'
    mode '0755'
end

#Group: Ubuntu/Base
#file: /opt/jiffy/gary/Public/Configs/Ubuntu/Base/CHROOTFILES/usr/local/scripts/sys_stats2syslog.sh
#version: 1
#file_check_hash: b36ed20e621e3a1255807f3aa7e32945
#file_ref_hash: b76ed0e8aba93e7a71e7a4f1cda20bcb
#md5sum_file: c316929a07be70a609c199acd2afb7eb
#filename: sys_stats2syslog.sh 
cookbook_file '/usr/local/scripts/sys_stats2syslog.sh' do
    source 'c316929a07be70a609c199acd2afb7eb'
    owner 'root'
    group 'root'
    mode '0755'
end

#Group: Ubuntu/Base
#file: /opt/jiffy/gary/Public/Configs/Ubuntu/Base/CHROOTFILES/etc/ssh/ssh_config
#version: 1
#file_check_hash: be07b8ad79f9669a8f83f0655fd95b1b
#file_ref_hash: c287b2ff8b4c90af04757131e2f015f4
#md5sum_file: 51b2c2b65171959d376dbd59741960cb
#filename: ssh_config 
cookbook_file '/etc/ssh/ssh_config' do
    source '51b2c2b65171959d376dbd59741960cb'
    owner 'root'
    group 'root'
    mode '0644'
end

#Group: Ubuntu/Base
#file: /opt/jiffy/gary/Public/Configs/Ubuntu/Base/CHROOTFILES/etc/ssh/sshd_config
#version: 1
#file_check_hash: 3151b3673c45588d00b283cd010d7584
#file_ref_hash: 8573aad8e3734d7cffc2de95468e1160
#md5sum_file: ac56c80abf47864597ff0581f9ebfe67
#filename: sshd_config 
cookbook_file '/etc/ssh/sshd_config' do
    source 'ac56c80abf47864597ff0581f9ebfe67'
    owner 'root'
    group 'root'
    mode '0644'
end

#Group: Ubuntu/Base
#file: /opt/jiffy/gary/Public/Configs/Ubuntu/Base/CHROOTFILES/etc/ssh/moduli
#version: 1
#file_check_hash: eb784cc9b1e3476a27dee25ba4d6571f
#file_ref_hash: 08180ab83a71b992dbc698da522cf3e1
#md5sum_file: b1c007bf229d5d1707a2aebe9732f13c
#filename: moduli 
cookbook_file '/etc/ssh/moduli' do
    source 'b1c007bf229d5d1707a2aebe9732f13c'
    owner 'root'
    group 'root'
    mode '0644'
end

#Group: Ubuntu/Base
#file: /opt/jiffy/gary/Public/Configs/Ubuntu/Base/CHROOTFILES/root/.bashrc
#version: 1
#file_check_hash: 7c3b2752406f41194225ed03b4183a7a
#file_ref_hash: 3a26605145978db3d89c3a259493e024
#md5sum_file: 45b6200d17c510bcb93ea64ca2aa8ada
#filename: .bashrc 
cookbook_file '/root/.bashrc' do
    source '45b6200d17c510bcb93ea64ca2aa8ada'
    owner 'root'
    group 'root'
    mode '0644'
end

