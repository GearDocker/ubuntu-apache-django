#Created by jiffy automatically.

file_cache_path "/var/jiffy-run"
cookbook_path ["/var/jiffy-run/cookbooks"]
role_path "/var/jiffy-run/roles"
