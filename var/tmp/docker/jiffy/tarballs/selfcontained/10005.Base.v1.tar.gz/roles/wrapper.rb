name "wrapper"

description "The wrapper cookbook self contained config Base.1,7f9efb3443b039666620a8cb51d9c76d.cd3cdd7755da2f9135b01f5789e245e4"

run_list "recipe[custom::default]"

