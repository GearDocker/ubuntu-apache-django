name "wrapper"

description "The wrapper cookbook self contained config 6XJB1NKM7C9XGK28"

run_list "role[apache_django]", "recipe[apt::default]", "recipe[build-essential::default]", "recipe[git::default]", "recipe[apache2::mod_wsgi]", "recipe[python::default]", "recipe[django::apache]"

