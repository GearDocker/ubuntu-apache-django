#Created by jiffy automatically.

group_name "Ubuntu/Apache/Django"
group_ref_hash "25112f2a2b64dcdbb770a24228f92331"
