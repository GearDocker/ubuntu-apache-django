#
# Copyright 2014, Gary Leong
default['domain_name'] = "default"
